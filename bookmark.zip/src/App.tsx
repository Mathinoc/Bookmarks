import React from 'react';
import logo from './logo.svg';
import './App.css';
import HomeView from './views/HomeView';

export default function App() {
  return (
    <div className="App">
      <HomeView />
    </div>
  );
}
