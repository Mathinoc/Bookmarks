import HomeComponent from '../components/HomeComponent';

export default function HomeView() {
  return (
    <>
      <HomeComponent />
    </>
  )
}
